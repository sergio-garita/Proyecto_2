/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package proyecto2.pkg1;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;

/**
 * 
 * Clase que representa la gestión de espacios de parqueo.
 * Se crean botones dinámicos que representan los espacios y se clasifican en:
 * - Discapacitados contraseña "1"
 * - Directores contraseña "2"
 * Al seleccionar un espacio, se marca como ocupado (rojo) o libre (color original).
 * Lv2 y Lv3 se sacaron de aqui
 * @author sheyr
 */
public class Lvs extends javax.swing.JFrame {

    /**
     * Constructor
     */
    public Lvs() {
        initComponents();
        setLocationRelativeTo(null);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        botones();
    }
     /**
     * Matriz que guarda los colores originales de los botones mas que todo para los especiales
     * Matriz de botones que representan los espacios de parqueo.
     */

    int filas = 4;
    int columnas = 5;
    int largoBoton = 140;
    int anchoBoton = 60;
    int ejeX = 20;
    int ejeY = 20;
    Color[][] 
    coloresOriginales = new Color[filas][columnas];
    public JToggleButton[][] JTBotones = new JToggleButton[filas][columnas];
    
    
    /**
     * Constructor que se creo para los demas niveles pero 
     * no me funciono me generaba error en el run al final
     */

     public Lvs(int filas, int columnas) {
        initComponents();
        this.filas = filas;
        this.columnas = columnas;
        setLocationRelativeTo(null);
        botones();
    }

        /**
     * Método que crea los botones de parqueo y los agrega al panel.
     * Solo los pude hacer con JToglleButton que es un boton binario
     * Establece formato
     */
    
    public void botones() {
        JTBotones = new JToggleButton[filas][columnas];
        int contadorParqueo = 1;
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                JTBotones[i][j] = new JToggleButton();
                JTBotones[i][j].setBounds(ejeX, ejeY, largoBoton, anchoBoton);
                JTBotones[i][j].setContentAreaFilled(false);
                JTBotones[i][j].setOpaque(true);
                // Espacios para discapacitado    
                if (i == 0 && j < 3) {
                    contadorParqueo = 1;
                    JTBotones[i][j].setBackground(Color.blue);
                    JTBotones[i][j].setText("Discapacitado  ");

                    // Espacios para directores 
                } else if (i == 1 && j < 3) {
                    JTBotones[i][j].setBackground(Color.ORANGE);
                    JTBotones[i][j].setText("Director ");

                    // Espacios libres
                } else {
                    JTBotones[i][j].setBackground(Color.GREEN);
                    JTBotones[i][j].setText("Espacio " + contadorParqueo);
                }
                coloresOriginales[i][j] = JTBotones[i][j].getBackground();
                AccionBotones accion = new AccionBotones();
                JTBotones[i][j].addActionListener(accion);
                pnlBotones.add(JTBotones[i][j]);
                contadorParqueo++;
                ejeX += 160;

            }
            ejeX = 20;
            ejeY += 70;

        }
    }
    
    public boolean pedirContrasena(int tipo) {
        String contrasena = JOptionPane.showInputDialog(this, "Introduce la contraseña:");

        if (contrasena != null) {
             if (tipo == 1 && contrasena.equals("1")) { // Contraseña para discapacitado
                 return true;
             }  else 
                if (tipo == 2 && contrasena.equals("2")) { // Contraseña para director
                  return true;
             } 
                else {
                     JOptionPane.showMessageDialog(this, "Contraseña incorrecta.");}
                     return false;
        }
            return false;
    }

    

    public class AccionBotones implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {

                    if (e.getSource().equals(JTBotones[i][j])) {
                        if (i == 0 && j < 3) {
                            if (pedirContrasena(1)) { // Verificar contraseña para discapacitados
                                JTBotones[i][j].setBackground(Color.RED);
                                JOptionPane.showMessageDialog(null, "El espacio se ocupo correctamente");
                            }
                        } else
                             if (i == 1 && j < 3) {
                             if (pedirContrasena(2)) { // Verificar contraseña para directores
                                JTBotones[i][j].setBackground(Color.RED);
                                JOptionPane.showMessageDialog(null, "El espacio se ocupo correctamente");
                            }
                        }
                        else {
                               if (JTBotones[i][j].isSelected()) {
                                 JTBotones[i][j].setBackground(Color.RED);
                                 JOptionPane.showMessageDialog(null, "El espacio se ocupo correctamente");
                                } 
                               else {
                                     JTBotones[i][j].setBackground(coloresOriginales[i][j]);
                                     JOptionPane.showMessageDialog(null, "El espacio se Libero correctamente");
                        }

                    }
                }
            }
        }
    }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jLabel1 = new javax.swing.JLabel();
        pnlBotones = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jMenu3.setText("jMenu3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setBackground(new java.awt.Color(102, 204, 255));
        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Nivel 1");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(100, 6, 110, 30);

        pnlBotones.setBackground(java.awt.Color.white);
        pnlBotones.setPreferredSize(new java.awt.Dimension(900, 300));

        javax.swing.GroupLayout pnlBotonesLayout = new javax.swing.GroupLayout(pnlBotones);
        pnlBotones.setLayout(pnlBotonesLayout);
        pnlBotonesLayout.setHorizontalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 900, Short.MAX_VALUE)
        );
        pnlBotonesLayout.setVerticalGroup(
            pnlBotonesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        getContentPane().add(pnlBotones);
        pnlBotones.setBounds(6, 47, 900, 300);

        jPanel2.setBackground(java.awt.Color.green);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 62, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 53, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2);
        jPanel2.setBounds(6, 353, 62, 53);

        jPanel3.setBackground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 56, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(270, 360, 56, 53);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Disponible ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(86, 366, 140, 40);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Ocupado");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(340, 360, 110, 50);

        jButton1.setBackground(new java.awt.Color(102, 204, 255));
        jButton1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(750, 370, 130, 50);

        jButton2.setBackground(new java.awt.Color(102, 204, 255));
        jButton2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Nivel 2");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(350, 10, 120, 29);

        jButton3.setBackground(new java.awt.Color(102, 204, 255));
        jButton3.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Nivel 3");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(610, 10, 130, 29);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Fondo.jpg"))); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(0, 0, 930, 440);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //
        Menu menu = new Menu();
        menu.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Lv2 dos = new Lv2();
        dos.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Lv3 tres = new Lv3();
        tres.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel pnlBotones;
    // End of variables declaration//GEN-END:variables

}
